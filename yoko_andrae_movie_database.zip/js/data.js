//All movies' data [Array]
    const movies =
    [
        {   title: "snow white", year: 1937, cover: 'https://image.tmdb.org/t/p/w640/wbVGRBYPRRahIZNGXY9TfHDUSc2.jpg',
            genres: ["family", "fantasy", "animation"],
            ratings: [3, 5, 6, 2]
        },
        {   title: "the pianist", year: 2002, cover: "https://image.tmdb.org/t/p/w640/11ioBctEepUPRhvqxrWR3Cou6M0.jpg",
            genres: ["drama", "war"],
            ratings: [7, 9, 10, 10]
        },
        {   title: "gladiator", year: 2000, cover: "https://image.tmdb.org/t/p/w640/9HHuKIB3djq1tgUsPDdmDQhN5b5.jpg",
            genres: ["action","drama", "adventure"],
            ratings: [7, 8, 8, 9]
        },
        {   title: "the queen", year: 2006, cover: "https://image.tmdb.org/t/p/w640/Ai8tz9c7Homb9mLg8baGhX1ABkR.jpg",
            genres: ["drama"],
            ratings: [6, 8, 5, 9]
        },
        {   title: "slumdog millionaire", year: 2008, cover: "https://image.tmdb.org/t/p/w640/ojgf8iJpS4VX6jJfWGLpuEx0wm.jpg",
            genres: ["drama","romance"],
            ratings: [7, 9, 10, 10]
        },
        {   title: "zootopia", year: 2016, cover: "https://image.tmdb.org/t/p/w640/1YzLAWykXzZhydoGJCqoVQ0gVyC.jpg",
            genres: ["animation", "family"],
            ratings: [6, 8, 7, 8]
        }
    ];